import { Card, CardContent } from "@/components/ui/card";
import aboutCooking from "@/assets/about-cooking.jpg";
import { Heart, Clock, Leaf, Users } from "lucide-react";

const AboutSection = () => {
  const features = [
    {
      icon: <Heart className="w-6 h-6" />,
      title: "Made Fresh Daily",
      description: "Every meal prepared with love and fresh ingredients"
    },
    {
      icon: <Leaf className="w-6 h-6" />,
      title: "Local Ingredients", 
      description: "Sourced from local farmers and markets"
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: "Fast Delivery",
      description: "Hot meals delivered within 45 minutes"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Friendly Service",
      description: "Treating every customer like family"
    }
  ];

  return (
    <section className="py-20 warm-gradient">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div>
            <h2 className="text-section font-bold text-foreground mb-6">
              Our Story
            </h2>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              HOMEMADE was born from a passion to serve wholesome, home-style meals to busy people who miss the taste of real food. We're not just a kitchen — we're a movement of flavor, culture, and community.
            </p>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Founded in 2025 in Kitui, our mission is to deliver <strong className="text-primary">quality, affordable, and hygienic meals</strong> that feel like they came from mum's pot.
            </p>
            
            <h3 className="text-xl font-semibold text-foreground mb-6">Why Choose Us?</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <Card key={index} className="border-0 gentle-shadow smooth-transition hover:shadow-food">
                  <CardContent className="p-4 text-center">
                    <div className="text-primary mb-3 flex justify-center">
                      {feature.icon}
                    </div>
                    <h4 className="font-semibold text-foreground mb-2">{feature.title}</h4>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          
          {/* Image */}
          <div className="relative">
            <img 
              src={aboutCooking} 
              alt="Fresh cooking preparation" 
              className="rounded-2xl w-full food-shadow smooth-transition hover:scale-105"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;