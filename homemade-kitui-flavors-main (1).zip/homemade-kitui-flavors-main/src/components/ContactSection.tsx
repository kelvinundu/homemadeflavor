import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, MessageCircle, Mail, Instagram, Facebook, Clock, MapPin, CreditCard } from "lucide-react";

const ContactSection = () => {
  const contactMethods = [
    {
      icon: <Phone className="w-6 h-6" />,
      label: "Phone/WhatsApp",
      value: "0718575827",
      action: "Call Now"
    },
    {
      icon: <Mail className="w-6 h-6" />,
      label: "Email",
      value: "kelvinmaundu@gmail.com",
      action: "Send Email"
    }
  ];

  const socialMedia = [
    {
      icon: <Instagram className="w-5 h-5" />,
      platform: "Instagram",
      handle: "@homemadecafe.ke"
    },
    {
      icon: <Facebook className="w-5 h-5" />,
      platform: "Facebook", 
      handle: "HOMEMADE Cafe Kenya"
    }
  ];

  return (
    <section className="py-20 warm-gradient">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-section font-bold text-foreground mb-4">
            Contact Us
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Ready to order or have questions? Get in touch with us. We're here to serve you!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-foreground mb-6">Get In Touch</h3>
            
            {/* Contact Methods */}
            <div className="space-y-4">
              {contactMethods.map((method, index) => (
                <Card key={index} className="gentle-shadow smooth-transition hover:shadow-food">
                  <CardContent className="p-4 flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="text-primary mr-3">
                        {method.icon}
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{method.label}</p>
                        <p className="text-muted-foreground">{method.value}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline">
                      {method.action}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* M-Pesa Payment */}
            <Card className="gentle-shadow bg-primary/5">
              <CardContent className="p-6 text-center">
                <div className="text-primary mb-2">
                  <CreditCard className="w-8 h-8 mx-auto" />
                </div>
                <h4 className="font-semibold text-foreground mb-2">M-Pesa Till Number</h4>
                <p className="text-2xl font-bold text-primary">2111</p>
                <p className="text-sm text-muted-foreground mt-2">For quick and secure payments</p>
              </CardContent>
            </Card>
          </div>

          {/* Operating Hours & Social */}
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-foreground mb-6">Visit Us</h3>
            
            {/* Operating Hours */}
            <Card className="gentle-shadow">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Clock className="w-6 h-6 text-primary mr-3" />
                  <h4 className="font-semibold text-foreground">Operating Hours</h4>
                </div>
                <div className="space-y-2 text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Monday - Saturday</span>
                    <span className="font-medium">7:00am - 9:00pm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sunday</span>
                    <span className="font-medium text-destructive">Closed</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Location */}
            <Card className="gentle-shadow">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <MapPin className="w-6 h-6 text-primary mr-3" />
                  <h4 className="font-semibold text-foreground">Location</h4>
                </div>
                <p className="text-muted-foreground">Serving Kitui Town & Surrounding Areas</p>
              </CardContent>
            </Card>

            {/* Social Media */}
            <Card className="gentle-shadow">
              <CardContent className="p-6">
                <h4 className="font-semibold text-foreground mb-4">Follow Us</h4>
                <div className="space-y-3">
                  {socialMedia.map((social, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="text-primary mr-3">
                          {social.icon}
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{social.platform}</p>
                          <p className="text-muted-foreground text-sm">{social.handle}</p>
                        </div>
                      </div>
                      <Button size="sm" variant="outline">
                        Follow
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;