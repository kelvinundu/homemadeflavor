import { Button } from "@/components/ui/button";
import heroFood from "@/assets/hero-food.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroFood})` }}
      >
        <div className="absolute inset-0 hero-gradient opacity-85"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 text-center text-white max-w-4xl px-4 sm:px-6 lg:px-8">
        <h1 className="text-hero font-bold mb-6 drop-shadow-lg">
          Welcome to <span className="block mt-2">HOMEMADE</span>
        </h1>
        <p className="text-xl sm:text-2xl mb-4 font-medium drop-shadow-md">
          Taste the Love in Every Bite!
        </p>
        <p className="text-lg sm:text-xl mb-8 opacity-90 max-w-2xl mx-auto">
          Your go-to online food café serving fresh, homemade meals right to your doorstep in Kitui.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            size="lg" 
            className="bg-white text-primary hover:bg-white/90 font-semibold px-8 py-3 text-lg smooth-transition"
          >
            Order Now
          </Button>
          <Button 
            variant="outline" 
            size="lg"
            className="border-white text-white hover:bg-white hover:text-primary font-semibold px-8 py-3 text-lg smooth-transition"
          >
            View Menu
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;