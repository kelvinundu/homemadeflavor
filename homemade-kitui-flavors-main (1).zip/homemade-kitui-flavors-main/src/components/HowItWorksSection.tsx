import { Card, CardContent } from "@/components/ui/card";
import { Menu, MessageCircle, CreditCard, Truck } from "lucide-react";

const HowItWorksSection = () => {
  const steps = [
    {
      icon: <Menu className="w-8 h-8" />,
      title: "Browse the Menu",
      description: "Explore our delicious selection of homemade Kenyan dishes"
    },
    {
      icon: <MessageCircle className="w-8 h-8" />,
      title: "Place Your Order",
      description: "Order via WhatsApp or our website - quick and easy!"
    },
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: "Pay via M-Pesa",
      description: "Secure payment through M-Pesa Till: 2111"
    },
    {
      icon: <Truck className="w-8 h-8" />,
      title: "We Cook & Deliver",
      description: "Fresh, hot meals delivered within 45 minutes"
    }
  ];

  return (
    <section className="py-20 warm-gradient">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-section font-bold text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Getting your favorite homemade meals is simple and fast. Here's how we make it happen:
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <Card key={index} className="text-center gentle-shadow smooth-transition hover:shadow-food hover:-translate-y-2">
              <CardContent className="p-6">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full text-primary mb-4">
                  {step.icon}
                </div>
                <div className="absolute -top-3 -right-3 bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">
                  {index + 1}
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  {step.title}
                </h3>
                <p className="text-muted-foreground">
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Card className="inline-block px-8 py-4 gentle-shadow bg-accent/10">
            <p className="text-lg font-medium text-foreground">
              <span className="text-accent font-semibold">Delivery available in Kitui</span> & surrounding areas
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;