import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import ugaliMeal from "@/assets/ugali-meal.jpg";
import pilauRice from "@/assets/pilau-rice.jpg";
import snacks from "@/assets/snacks.jpg";

const MenuSection = () => {
  const menuCategories = [
    {
      id: 1,
      name: "Traditional Kenyan Dishes",
      image: ugaliMeal,
      items: ["Ugali with Sukuma & Nyama", "Mukimo Special", "Traditional Stew"],
      price: "KES 200-350",
      description: "Authentic Kenyan flavors from our kitchen to your table"
    },
    {
      id: 2,
      name: "Rice & Pilau Specials",
      image: pilauRice,
      items: ["Beef Pilau", "Chicken Pilau", "Vegetable Rice"],
      price: "KES 250-400",
      description: "Aromatic rice dishes cooked with traditional spices"
    },
    {
      id: 3,
      name: "Snacks & Bites",
      image: snacks,
      items: ["Fresh Samosas", "Grilled Sausages", "Crispy Chips"],
      price: "KES 50-200",
      description: "Perfect for quick bites and sharing"
    }
  ];

  const additionalCategories = [
    "Breakfast Specials",
    "Healthy Choices (Salads & Grilled)",
    "Fresh Juices & Drinks"
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-section font-bold text-foreground mb-4">
            Our Menu
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover our delicious selection of homemade meals, prepared fresh daily with love and authentic Kenyan flavors.
          </p>
        </div>

        {/* Featured Categories */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {menuCategories.map((category) => (
            <Card key={category.id} className="overflow-hidden gentle-shadow smooth-transition hover:shadow-food hover:-translate-y-2">
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="w-full h-full object-cover smooth-transition hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <p className="text-lg font-semibold">{category.price}</p>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-card font-semibold text-foreground mb-2">
                  {category.name}
                </h3>
                <p className="text-muted-foreground mb-4 text-sm">
                  {category.description}
                </p>
                <ul className="text-sm text-muted-foreground mb-4 space-y-1">
                  {category.items.map((item, index) => (
                    <li key={index} className="flex items-center">
                      <span className="w-2 h-2 bg-primary rounded-full mr-2"></span>
                      {item}
                    </li>
                  ))}
                </ul>
                <Button className="w-full smooth-transition" size="sm">
                  Order Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Categories */}
        <div className="text-center">
          <h3 className="text-xl font-semibold text-foreground mb-6">Also Available:</h3>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {additionalCategories.map((category, index) => (
              <Card key={index} className="px-6 py-3 gentle-shadow">
                <p className="text-foreground font-medium">{category}</p>
              </Card>
            ))}
          </div>
          <Button size="lg" variant="outline" className="smooth-transition" asChild>
            <a href="/menu">View Full Menu</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default MenuSection;