import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";

const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Mercy",
      location: "Kitui",
      review: "I order from HOMEMADE almost every day — tastes just like mum's cooking!",
      rating: 5
    },
    {
      name: "Kevin",
      location: "Machakos", 
      review: "Fast, fresh and affordable. I love their pilau!",
      rating: 5
    },
    {
      name: "Grace",
      location: "Kitui Town",
      review: "The ugali and sukuma is perfect every time. Highly recommend!",
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-section font-bold text-foreground mb-4">
            What Our Customers Say
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Don't just take our word for it - hear from our happy customers who love our homemade meals.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="gentle-shadow smooth-transition hover:shadow-food hover:-translate-y-2">
              <CardContent className="p-6 relative">
                <Quote className="absolute top-4 right-4 w-6 h-6 text-primary/30" />
                
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                
                <blockquote className="text-foreground mb-4 italic leading-relaxed">
                  "{testimonial.review}"
                </blockquote>
                
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                    <span className="font-semibold text-primary text-sm">
                      {testimonial.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;