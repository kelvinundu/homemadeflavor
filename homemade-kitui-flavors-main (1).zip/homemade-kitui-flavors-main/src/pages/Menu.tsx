import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { ArrowLeft, ShoppingCart } from "lucide-react";
import ugaliMeal from "@/assets/ugali-meal.jpg";
import pilauRice from "@/assets/pilau-rice.jpg";
import snacks from "@/assets/snacks.jpg";

const Menu = () => {
  const menuCategories = [
    {
      id: 1,
      name: "Traditional Kenyan Dishes",
      image: ugaliMeal,
      items: [
        { name: "Ugali with Sukuma & Nyama", price: "KES 300", description: "Traditional ugali served with collard greens and beef stew" },
        { name: "Mukimo Special", price: "KES 250", description: "Mashed green peas, potatoes, and maize with traditional vegetables" },
        { name: "Traditional Stew", price: "KES 200", description: "Hearty beef stew with mixed vegetables" },
        { name: "Nyama Choma", price: "KES 350", description: "Grilled goat meat served with ugali" },
        { name: "Githeri Special", price: "KES 180", description: "Mixed beans and maize with vegetables" }
      ]
    },
    {
      id: 2,
      name: "Rice & Pilau Specials",
      image: pilauRice,
      items: [
        { name: "Beef Pilau", price: "KES 400", description: "Aromatic spiced rice with tender beef pieces" },
        { name: "Chicken Pilau", price: "KES 380", description: "Fragrant rice with succulent chicken" },
        { name: "Vegetable Rice", price: "KES 250", description: "Colorful rice with mixed vegetables" },
        { name: "Plain Rice", price: "KES 150", description: "Simple steamed rice" },
        { name: "Coconut Rice", price: "KES 200", description: "Rice cooked in coconut milk" }
      ]
    },
    {
      id: 3,
      name: "Breakfast Specials",
      items: [
        { name: "Mandazi & Chai", price: "KES 80", description: "Fresh mandazi with spiced tea" },
        { name: "Chapati & Beans", price: "KES 120", description: "Soft chapati with seasoned beans" },
        { name: "Ugali & Tea", price: "KES 70", description: "Morning ugali with tea" },
        { name: "Bread & Egg", price: "KES 100", description: "Toasted bread with boiled egg" },
        { name: "Porridge", price: "KES 60", description: "Traditional millet or maize porridge" }
      ]
    },
    {
      id: 4,
      name: "Snacks & Bites",
      image: snacks,
      items: [
        { name: "Fresh Samosas", price: "KES 20", description: "Crispy pastry with savory filling (per piece)" },
        { name: "Grilled Sausages", price: "KES 150", description: "Juicy grilled sausages with kachumbari" },
        { name: "Crispy Chips", price: "KES 120", description: "Golden french fries" },
        { name: "Boiled Eggs", price: "KES 50", description: "Two fresh boiled eggs" },
        { name: "Roasted Maize", price: "KES 40", description: "Grilled maize on the cob" }
      ]
    },
    {
      id: 5,
      name: "Healthy Choices",
      items: [
        { name: "Garden Salad", price: "KES 180", description: "Fresh mixed greens with vegetables" },
        { name: "Grilled Chicken Salad", price: "KES 320", description: "Grilled chicken breast on mixed greens" },
        { name: "Fruit Salad", price: "KES 150", description: "Seasonal fresh fruits" },
        { name: "Grilled Fish", price: "KES 280", description: "Fresh grilled tilapia with vegetables" },
        { name: "Steamed Vegetables", price: "KES 120", description: "Mixed steamed seasonal vegetables" }
      ]
    },
    {
      id: 6,
      name: "Fresh Juices & Drinks",
      items: [
        { name: "Fresh Orange Juice", price: "KES 80", description: "Freshly squeezed orange juice" },
        { name: "Passion Fruit Juice", price: "KES 100", description: "Sweet and tangy passion fruit" },
        { name: "Mixed Fruit Juice", price: "KES 120", description: "Blend of seasonal fruits" },
        { name: "Sodas", price: "KES 60", description: "Various soft drinks" },
        { name: "Mineral Water", price: "KES 30", description: "500ml bottled water" },
        { name: "Chai (Tea)", price: "KES 40", description: "Traditional spiced tea" }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-warm-gradient py-6">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center text-white hover:text-white/80 smooth-transition">
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Home
            </Link>
            <h1 className="text-hero font-bold text-white text-center">
              HOMEMADE Menu
            </h1>
            <div className="w-24"></div>
          </div>
        </div>
      </div>

      {/* Menu Content */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            All our meals are prepared fresh daily with love, using quality local ingredients. 
            Order via WhatsApp: <strong>0718575827</strong> or M-Pesa Till: <strong>2111</strong>
          </p>
        </div>

        {/* Menu Categories */}
        <div className="space-y-16">
          {menuCategories.map((category) => (
            <div key={category.id} className="fade-in">
              <div className="flex items-center gap-4 mb-8">
                {category.image && (
                  <div className="w-16 h-16 rounded-full overflow-hidden gentle-shadow">
                    <img 
                      src={category.image} 
                      alt={category.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <h2 className="text-section font-bold text-foreground">
                  {category.name}
                </h2>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {category.items.map((item, index) => (
                  <Card key={index} className="gentle-shadow smooth-transition hover:shadow-food hover:-translate-y-1">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-card text-foreground">{item.name}</CardTitle>
                        <Badge variant="secondary" className="ml-2 font-semibold">
                          {item.price}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <p className="text-muted-foreground text-sm mb-4">
                        {item.description}
                      </p>
                      <Button size="sm" className="w-full smooth-transition">
                        <ShoppingCart className="w-4 h-4 mr-2" />
                        Order Now
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Contact Information */}
        <div className="mt-20 text-center bg-muted/30 rounded-lg p-8">
          <h3 className="text-xl font-bold text-foreground mb-4">Ready to Order?</h3>
          <div className="space-y-2 text-muted-foreground mb-6">
            <p>WhatsApp: <strong>0718575827</strong></p>
            <p>M-Pesa Till: <strong>2111</strong></p>
            <p>Operating Hours: Mon-Sat 7:00am - 9:00pm</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="smooth-transition">
              Order via WhatsApp
            </Button>
            <Button size="lg" variant="outline" className="smooth-transition">
              Call Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Menu;